#!/bin/bash

panaudota_vietos_baitais=$(du -sb | cut -f1)
laisvos_vietos_baitais=$((10*1024*1024*1024 - $panaudota_vietos_baitais)) #1GB = 1024*1024*1024, 10GB skirta studentams: <https://mif.vu.lt/itwiki/duk:disk_space>
panaudota_vieta_procentais=$(($panaudota_vieta_baitais * 100 / $laisvos_vietos_baitais))

echo "Panaudota vietos (baitais): $panaudota_vietos_baitais"
echo "Liko laisvos vietos (baitais): $laisvos_vietos_baitais"
echo "Panaudota vietos (procentais): $panaudota_vieta_procentais"
echo "Daugiausiai vietos užimantys failai ir katalogai: "
du -s -b * | sort -k 1 -n -r