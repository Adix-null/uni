import sys

def is_prime(num):
    if num < 2:
        return False

    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False

    return True

def find_primes(start, end):
    for i in range(start, end):
        if is_prime(i):
            print(i)

def to_num(ivestis):
    num = None
    try:
        num = int(ivestis)
    except ValueError:
        pass
    return num

def check_num(num):
    verte = to_num(num)
    if verte == None:
        print("Reikia įvesti sveikąjį skaičių")
        sys.exit(0)
    if verte < 1:
        print("Reikia įvesti teigiamą skaičių")
        sys.exit(0)
    return verte

print("Pirminių skaičių paieškos programa")
print("Programa ras pirminius skaičius nurodytame intervale")
num_st = input("Įveskite intervalo pradžią: ")
num_st = check_num(num_st)
num_end = input("Įveskite intervalo pabaigą: ")
num_end = check_num(num_end)
if num_st > num_end:
    tmp = num_st
    num_st  = num_end
    num_end = tmp
print("Pirminų skaičių ieškoma intervale [" + str(num_st) + ", " + str(num_end) + "]")
find_primes(num_st, num_end)