#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import numpy as np

f = open("transistor-counts.csv", "r", encoding="utf8")
row_cnt = 0
proc_names = []
trans_num = []
year = []
for row in f:
    row = row.strip().split(",")
    if row_cnt > 0:
        proc_names.append(row[0])
        trans_num.append(int(row[1]))
        year.append(int(row[2]))
    row_cnt+=1
    #print(row)

#plt.plot(year, trans_num)
plt.scatter(year, trans_num, label="Sukurti procesoriai")
plt.yscale("log")
plt.xlabel("Išleidimo metai")
plt.ylabel("Tranzistorių skaičius")
plt.title("Mūro dėsnis")

n = [trans_num[0]]

for y_i in range(min(year), max(year) + 1):
    n.append(n[0] * 2**((max(year) + 1 - min(year)) / 2))

plt.plot([min(year), max(year)], [trans_num[0], n[-1]], linestyle='--', label="Prognozė")
plt.legend()

plt.savefig("moores_law.pdf", format="pdf")
plt.savefig("moores_law.png", format="png")
plt.savefig("moores_law.svg", format="svg")

plt.show()
