#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np\

X = np.linspace(-5, 5, 50001)

F1 = 1/(np.cbrt(X))
F2 = 1/X
F3 = 1/(np.pow(X, 2))

plt.xlabel("x")
plt.ylabel("y")
plt.title("Hiperbolės")

plt.xlim(-5, 5)
plt.ylim(-15, 15)
plt.plot(X, F1, linestyle="-", label=r"$f_1(x)=\frac{1}{\sqrt[3]{x}}$")
plt.plot(X, F2, linestyle="--", color="gold", label=r"$f_2(x)=\frac{1}{x}$")
plt.plot(X, F3, linestyle=":", color="green", label=r"$f_3(x)=\frac{1}{x^2}$")
plt.legend()
plt.savefig("graf1.pdf", format="pdf")
plt.close()

X = np.linspace(-6, 6, 50001)
F4 = np.sin(np.pow(X, 2))

plt.xlabel("x")
plt.ylabel("y")
plt.title(r"$f(x)=\sin({x^2})$")

plt.xlim(-6, 6)
plt.ylim(-1.15, 1.15)
plt.plot(X, F4, linestyle=":")
plt.savefig("graf2.pdf", format="pdf")

plt.show()
plt.close()